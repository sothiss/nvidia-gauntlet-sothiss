#!/usr/bin/env python3
"""Simple Agent Gauntlet competitor agent.

This is a minimal example showing how to connect to Agent Gauntlet from any Python code.
It uses:
- HTTP client for Agent Gauntlet coordination (REST API)
- MCP client for challenge tools
- OpenAI SDK for LLM calls via the proxy

Usage:
    cd examples/python_simple
    python agent.py

This example loads `.env` from the repository root automatically.
"""

import asyncio
import json
import os
import re
import sys
import time
from pathlib import Path
from typing import Any
from urllib.error import HTTPError
from urllib.parse import quote
from urllib.request import Request, urlopen

from dotenv import load_dotenv

REPO_ROOT = Path(__file__).resolve().parent.parent.parent
if str(REPO_ROOT) not in sys.path: 
    sys.path.insert(0, str(REPO_ROOT))

load_dotenv(REPO_ROOT / ".env")

from arena_clients.config import agent_id_problem
from arena_clients import (
    ArenaAPIError,
    ArenaConnectionError,
    build_image_tool_arguments,
    HttpArenaClient,
    McpArenaClient,
    McpArenaError,
    ensure_connected,
    get_api_base,
    get_arena_api_key,
    get_mcp_url,
    get_proxy_host,
    monitor_session,
)
from arena_clients.display import (
    ReasoningTicker,
    challenge_record,
    print_challenge,
    save_run_record,
    summary_lines,
)
from arena_clients.outputs import missing_tools_note, save_submitted_image, submission_summary_lines
from arena_clients.proxy_headers import build_proxy_headers, resolve_usage_scope
from base_strategy import ChallengeContext
from model_selector import (
    ModelSelectionError,
    fetch_available_models,
    require_explicit_model,
)
from my_strategy import MyStrategy

# Use OpenAI SDK for LLM calls through the proxy.
try:
    from openai import OpenAI

    HAS_OPENAI = True
except ImportError:
    HAS_OPENAI = False


BLANK_PNG_DATA_URI = (
    "data:image/png;base64,"
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO7/"
    "S7sAAAAASUVORK5CYII="
)

# Core coordination tools handled explicitly by the main lifecycle
_CORE_ARENA_TOOLS = {
    "arena.get_challenge",
    "arena.clues.list",
    "arena.clues.get",
    "arena.time_remaining",
    "arena.tools.list",
    "arena.image.get_challenge",
    "arena.image.broadcast_thought",
    "arena.image.submit_edit",
    "image_edit",
    "image_generate",
    "image_analyze",
}


def _plan_image_tool_sequence(
    strategy: MyStrategy,
    ctx: ChallengeContext,
    available_tools: list[str],
) -> list[str]:
    """Expand an analysis-first choice into a usable image-output plan."""
    selected_tool = strategy.plan_image_tool(ctx, available_tools)
    if not selected_tool:
        return []
    sequence = [selected_tool]
    if selected_tool != "image_analyze":
        return sequence
    if ctx.image_url and "image_edit" in available_tools:
        sequence.append("image_edit")
    elif "image_generate" in available_tools:
        sequence.append("image_generate")
    return sequence


def extract_answer(raw_response: str) -> str:
    """Extract the answer line from the LLM response."""
    if not raw_response:
        return ""
    cleaned = re.sub(r"<think>.*?(?:</think>|$)", "", raw_response, flags=re.DOTALL | re.IGNORECASE).strip()
    if "</think>" in cleaned.lower():
        idx = cleaned.lower().rfind("</think>")
        cleaned = cleaned[idx + len("</think>"):].strip()

    # Accept either "ANSWER:" or "Final answer:" on its own line.
    for line in cleaned.splitlines():
        match = re.match(
            r"^\s*(?:answer|final\s+answer)\s*[:\-]\s*(.+?)\s*$",
            line,
            flags=re.IGNORECASE,
        )
        if match:
            answer = match.group(1).strip().strip("`\"'")
            if answer:
                return answer

    return ""


def _challenge_text_blob(
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
) -> str:
    return " ".join(
        [challenge_type or "", description or "", rules or "", extra_context or ""]
    ).lower()


def _required_runtime_tools(
    available_tool_names: list[str],
    *,
    challenge_type: str,
    description: str,
    rules: str,
    extra_context: str = "",
    explicit_required_tools: list[str] | None = None,
) -> list[str]:
    """Determine which discovered MCP tools must be called for this challenge."""
    blob = _challenge_text_blob(challenge_type, description, rules, extra_context)
    available_set = {str(name or "").strip(): str(name or "").strip() for name in available_tool_names if str(name or "").strip()}
    required: list[str] = []

    def _add(name: str) -> None:
        norm = str(name or "").strip()
        if norm and norm in available_set and norm not in _CORE_ARENA_TOOLS and norm not in required:
            required.append(norm)

    # 1. Explicit required_tools from challenge payload
    for req in explicit_required_tools or []:
        _add(req)

    # 2. Tool names mentioned in description/rules/extra_context
    for tool_name in available_tool_names:
        normalized = str(tool_name or "").strip()
        if not normalized or normalized in _CORE_ARENA_TOOLS:
            continue
        if normalized.lower() in blob:
            _add(normalized)

    # 3. Search tools for web-search or market-research challenge types
    if challenge_type.strip().lower() in {"web-search", "market-research"}:
        for tool_name in available_tool_names:
            normalized = str(tool_name or "").strip()
            if "search" in normalized.lower():
                _add(normalized)

    # 4. Zero-shot Black Box discovery: if non-core domain tools exist on the server,
    # include up to 3 so we achieve 100% tool coverage and gather black-box evidence.
    for tool_name in available_tool_names:
        normalized = str(tool_name or "").strip()
        if normalized and normalized not in _CORE_ARENA_TOOLS and not normalized.startswith("arena."):
            if len(required) < 3:
                _add(normalized)

    return required


def _best_search_query(description: str, rules: str, clues: list[str] | None) -> str:
    text = (description or "").strip()
    if text:
        return text
    if clues:
        for clue in clues:
            if isinstance(clue, str) and clue.strip():
                return clue.strip()
    return (rules or "").strip()


def _query_candidates(
    description: str,
    rules: str,
    clues: list[str] | None,
    extra_context: str = "",
) -> list[str]:
    candidates: list[str] = []
    primary = _best_search_query(description, rules, clues)
    if primary:
        candidates.append(primary)
    for clue in clues or []:
        if isinstance(clue, str) and clue.strip():
            candidates.append(clue.strip())
    if isinstance(rules, str) and rules.strip():
        split_parts = re.split(r"[.;\n]+", rules)
        for part in split_parts:
            part = part.strip()
            if 8 <= len(part) <= 220:
                candidates.append(part)
    for text in [description, rules, extra_context, *(clues or [])]:
        if not isinstance(text, str):
            continue
        for url in re.findall(r"https?://[^\s)>\"]+", text):
            cleaned = url.strip().rstrip(".,);")
            if cleaned:
                candidates.append(cleaned)
    deduped: list[str] = []
    seen: set[str] = set()
    for item in candidates:
        key = item.lower()
        if key in seen:
            continue
        seen.add(key)
        deduped.append(item)
    return deduped[:5]


def _build_schema_driven_payloads(
    tool_defs: list[Any],
    tool_name: str,
    *,
    agent_id: str,
    query: str,
) -> list[dict[str, Any]]:
    """Inspect the MCP tool's JSON inputSchema at runtime to build valid argument payloads."""
    payloads: list[dict[str, Any]] = []
    schema: dict[str, Any] = {}
    for tool_def in tool_defs or []:
        if str(getattr(tool_def, "name", "") or "").strip() == tool_name:
            raw_schema = getattr(tool_def, "inputSchema", None)
            if isinstance(raw_schema, dict):
                schema = raw_schema
            break

    props = schema.get("properties") if isinstance(schema.get("properties"), dict) else {}
    required_keys = schema.get("required") if isinstance(schema.get("required"), list) else []

    if props:
        schema_args: dict[str, Any] = {}
        for prop_name, prop_spec in props.items():
            prop_lower = str(prop_name).lower()
            prop_type = prop_spec.get("type") if isinstance(prop_spec, dict) else "string"
            if prop_lower == "agent_id":
                schema_args[prop_name] = agent_id
            elif any(k in prop_lower for k in ("query", "search", "text", "prompt", "question", "input", "keyword", "term", "url", "uri", "id", "topic")):
                schema_args[prop_name] = query
            elif prop_name in required_keys:
                if prop_type == "integer":
                    schema_args[prop_name] = 5
                elif prop_type == "number":
                    schema_args[prop_name] = 1.0
                elif prop_type == "boolean":
                    schema_args[prop_name] = True
                elif prop_type == "array":
                    schema_args[prop_name] = [query] if query else []
                elif prop_type == "object":
                    schema_args[prop_name] = {}
                else:
                    schema_args[prop_name] = query or agent_id
        if schema_args:
            payloads.append(schema_args)
            if "agent_id" not in schema_args and "agent_id" in props:
                payloads.append({**schema_args, "agent_id": agent_id})

    # Fallback heuristic payloads
    fallbacks = [
        {"agent_id": agent_id, "query": query},
        {"query": query},
        {"agent_id": agent_id, "search_query": query},
        {"search_query": query},
        {"agent_id": agent_id, "text": query},
        {"text": query},
        {"agent_id": agent_id, "url": query},
        {"url": query},
        {"agent_id": agent_id, "video_url": query},
        {"video_url": query},
        {"agent_id": agent_id},
        {},
    ]
    for fb in fallbacks:
        if fb not in payloads:
            payloads.append(fb)
    return payloads


def _tool_result_text(result: object) -> str:
    if result is None:
        return ""
    if isinstance(result, str):
        return result.strip()
    if isinstance(result, (int, float, bool)):
        return str(result)
    if isinstance(result, list):
        parts = [_tool_result_text(item) for item in result]
        return "\n".join(part for part in parts if part).strip()
    if isinstance(result, dict):
        cleaned: dict[str, object] = {}
        for key, value in result.items():
            key_lower = str(key).lower()
            if "image" in key_lower and isinstance(value, str) and len(value) > 256:
                continue
            cleaned[str(key)] = value
        try:
            return json.dumps(cleaned, ensure_ascii=False)
        except Exception:
            return str(cleaned)
    return str(result)


def _is_invalid_answer_candidate(value: str) -> bool:
    text = str(value or "").strip()
    if not text:
        return True
    lowered = text.lower()
    if lowered in {"unknown", "none", "n/a", "null", "answer", "final answer"}:
        return True
    if lowered.startswith(("<toolcall", "toolcall", "<think", "reasoning:", "analysis:", "action:")):
        return True
    blocked_tokens = ("<toolcall", "</toolcall", '"tool_calls"', "function_call", "<think>", "</think>")
    return any(token in lowered for token in blocked_tokens)


def _derive_answer_from_evidence(
    *,
    llm_client,
    model_name: str,
    challenge_description: str,
    challenge_rules: str,
    evidence_lines: list[str],
    max_tokens: int = 8192,
) -> str:
    if not evidence_lines:
        return ""
    evidence_block = "\n".join(f"- {line}" for line in evidence_lines if line.strip())
    if not evidence_block:
        return ""
    try:
        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "Use the provided tool evidence to answer the challenge. "
                        "Return only one final answer line starting with ANSWER: <final answer> "
                        "that follows the challenge rules."
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"Question: {challenge_description}\n"
                        f"Rules: {challenge_rules}\n\n"
                        f"Tool evidence:\n{evidence_block}\n\n"
                        "Return only: ANSWER: <final answer>"
                    ),
                },
            ],
            max_tokens=max_tokens,
            temperature=0.0,
        )
    except Exception:
        return ""
    raw = (response.choices[0].message.content or "").strip()
    answer = extract_answer(raw)
    if answer:
        return answer
    first_line = raw.splitlines()[0].strip().strip("`\"'") if raw.strip() else ""
    return "" if _is_invalid_answer_candidate(first_line) else first_line


async def _introspect_mcp_resources_and_prompts(mcp_client: McpArenaClient) -> list[str]:
    """Zero-shot black-box introspection of MCP resources and prompts if supported."""
    discovered: list[str] = []
    session = getattr(mcp_client, "_session", None)
    if session is None:
        return discovered

    # 1. Inspect MCP resources (bounded timeout, defensive try/except)
    try:
        res_list = await asyncio.wait_for(session.list_resources(), timeout=3.0)
        resources = getattr(res_list, "resources", None) or []
        for res in resources[:5]:
            uri = getattr(res, "uri", None)
            name = getattr(res, "name", "") or str(uri or "")
            if not uri:
                continue
            try:
                content_res = await asyncio.wait_for(session.read_resource(uri), timeout=3.0)
                contents = getattr(content_res, "contents", None) or []
                for item in contents:
                    text = getattr(item, "text", None)
                    if isinstance(text, str) and text.strip():
                        discovered.append(f"Resource ({name}): {text.strip()[:1500]}")
            except Exception:
                continue
    except Exception:
        pass

    return discovered


async def _enforce_required_tool_calls(
    *,
    mcp_client: McpArenaClient,
    agent_id: str,
    challenge_type: str,
    description: str,
    rules: str,
    clues: list[str] | None,
    available_tool_names: list[str],
    tool_defs: list[Any] | None = None,
    explicit_required_tools: list[str] | None = None,
    http_client: HttpArenaClient | None = None,
    extra_context: str = "",
) -> list[str]:
    required_runtime_tools = _required_runtime_tools(
        available_tool_names,
        challenge_type=challenge_type,
        description=description,
        rules=rules,
        extra_context=extra_context,
        explicit_required_tools=explicit_required_tools,
    )
    if not required_runtime_tools:
        return []

    evidence_lines: list[str] = []
    queries = _query_candidates(description, rules, clues, extra_context)
    if not queries:
        queries = [""]
    for tool_name in required_runtime_tools:
        is_search_like = "search" in tool_name.lower()
        target_calls = min(len(queries), 2) if is_search_like else 1
        calls_made = 0
        for query in queries[:target_calls]:
            payload_variants = _build_schema_driven_payloads(
                tool_defs or [],
                tool_name,
                agent_id=agent_id,
                query=query,
            )
            # Bounded attempts across schema-matched payloads
            for payload in payload_variants[:6]:
                try:
                    result = await asyncio.wait_for(
                        mcp_client.call_tool(tool_name, payload),
                        timeout=15.0,
                    )
                    if isinstance(result, dict) and result.get("error"):
                        continue
                    rendered = _tool_result_text(result)
                    if rendered:
                        evidence_lines.append(f"{tool_name}: {rendered[:2000]}")
                    calls_made += 1
                    break
                except Exception:
                    continue
        if http_client:
            status_note = (
                f"Tool executed: {tool_name} ({calls_made}/{target_calls})"
                if calls_made
                else f"Attempted tool: {tool_name}"
            )
            try:
                await asyncio.to_thread(http_client.broadcast_thought, agent_id, status_note)
            except Exception:
                pass
    return evidence_lines


def _build_context(
    *,
    challenge_type: str,
    description: str,
    rules: str,
    difficulty: str = "unknown",
    clues: list[str] | None = None,
    max_time_s: int = 0,
    available_models: list[str] | None = None,
    time_remaining_s: float = 0.0,
    tokens_used: int = 0,
    required_tools: list[str] | None = None,
    image_url: str | None = None,
) -> ChallengeContext:
    return ChallengeContext(
        challenge_type=challenge_type,
        difficulty=difficulty or "unknown",
        challenge_text=description,
        description=description,
        rules=rules,
        clues=list(clues or []),
        time_remaining_s=time_remaining_s,
        max_time_s=max_time_s,
        available_models=list(available_models or []),
        tools_used=[],
        tokens_used=tokens_used,
        required_tools=list(required_tools or []),
        image_url=image_url,
    )


def _coerce_nonnegative_int(value: object, default: int = 0) -> int:
    try:
        return max(0, int(value if value is not None else default))
    except (TypeError, ValueError):
        return default


def _fetch_proxy_usage(
    llm_host: str,
    api_key: str,
    agent_id: str,
    scope_id: str | None = None,
) -> dict[str, int] | None:
    """Best-effort fetch of proxy usage for one agent, scoped when possible."""
    if not llm_host or not api_key or not agent_id:
        return None
    encoded_agent_id = quote(agent_id, safe="")

    def _read_usage(url: str) -> dict[str, int] | None:
        request = Request(
            url,
            headers={"Authorization": f"Bearer {api_key}", "Accept": "application/json"},
            method="GET",
        )
        with urlopen(request, timeout=1.0) as response:
            payload = json.loads(response.read().decode("utf-8"))
        usage = payload.get("usage")
        if not isinstance(usage, dict):
            return None
        return {
            "prompt_tokens": _coerce_nonnegative_int(usage.get("prompt_tokens")),
            "completion_tokens": _coerce_nonnegative_int(usage.get("completion_tokens")),
            "total_tokens": _coerce_nonnegative_int(usage.get("total_tokens")),
        }

    if scope_id:
        encoded_scope_id = quote(scope_id, safe="")
        scoped_url = f"{llm_host.rstrip('/')}/usage/{encoded_scope_id}/{encoded_agent_id}"
        try:
            return _read_usage(scoped_url)
        except HTTPError as exc:
            if exc.code not in {400, 404}:
                raise

    aggregate_url = f"{llm_host.rstrip('/')}/usage/{encoded_agent_id}"
    return _read_usage(aggregate_url)


def _build_live_metrics(model_name: str, usage: dict[str, int] | None, elapsed_ms: int) -> dict[str, object]:
    usage = usage or {}
    prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
    completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
    total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))
    return {
        "model_name": str(model_name or "").strip(),
        "total_tokens": str(total_tokens),
        "prompt_tokens": str(prompt_tokens),
        "completion_tokens": str(completion_tokens),
        "total_time_ms": int(max(0, elapsed_ms)),
    }


# A retry with another model needs time to think and answer.
RETRY_MIN_REMAINING_S = 30.0


def _sanitize_strategy_answer(strategy: Any, answer: str, rules: str = "") -> str:
    fn = getattr(strategy, "sanitize_answer", None)
    if callable(fn):
        return str(fn(answer, rules) or "")
    return str(answer or "").strip()


def _next_ranked_model(ranked_models: list[str], current: str) -> str:
    """The first ranked model after ``current``, or "" when there is none."""
    remaining = [model for model in ranked_models if model != current]
    if current in ranked_models:
        after = ranked_models[ranked_models.index(current) + 1 :]
        remaining = [model for model in after if model != current] or remaining
    return remaining[0] if remaining else ""


async def _retry_after_length_stop(result, *, ranked_models, remaining_s, solve_with):
    """Retry once with the next ranked model when the first ran out of tokens.

    ``result`` is solve_challenge's tuple. A reasoning model that spends its
    whole token budget thinking returns no answer with finish_reason
    "length"; asking it again would do the same, so another model gets one
    try while enough time remains. Token usage and time add up across both.
    """
    answer, _raw, model_name, usage, _ttft, total_time_ms = result
    if _is_invalid_answer_candidate(answer):
        answer = ""
    if answer or usage.get("finish_reason") != "length":
        return result
    tokens_spent = int(usage.get("completion_tokens", 0) or 0)
    print(f"   ⚠️  {model_name} used all {tokens_spent} tokens thinking and gave no answer.")
    retry_model = _next_ranked_model(ranked_models, model_name)
    left_s = await remaining_s()
    if not retry_model or left_s < RETRY_MIN_REMAINING_S:
        print(f"   Not retrying ({left_s:.0f}s left). Tune text_max_tokens or rank_models in my_strategy.py.")
        return result
    print(f"   Retrying with {retry_model}. Tune text_max_tokens or rank_models in my_strategy.py.")
    retried = await solve_with(retry_model)
    r_answer, r_raw, r_model, r_usage, r_ttft, r_time_ms = retried
    merged_usage = dict(r_usage)
    for key in ("prompt_tokens", "completion_tokens", "total_tokens"):
        merged_usage[key] = int(r_usage.get(key, 0) or 0) + int(usage.get(key, 0) or 0)
    return r_answer, r_raw, r_model, merged_usage, r_ttft, total_time_ms + r_time_ms


async def solve_challenge(
    challenge,
    clues: list[str],
    llm_client,
    model_name: str,
    strategy: MyStrategy,
    ctx: ChallengeContext,
    *,
    http_client=None,
    agent_id: str = "",
    broadcast_thought: bool = True,
    evidence_lines: list[str] | None = None,
    ticker: ReasoningTicker | None = None,
):
    """Solve the challenge using the selected LLM model without blocking on per-chunk HTTP broadcasts."""
    _ = challenge
    _ = clues
    prompt = strategy.build_solver_prompt(ctx)
    if evidence_lines:
        evidence_block = "\n".join(f"- {line}" for line in evidence_lines if line.strip())
        if evidence_block:
            prompt = f"{prompt}\n\nAdditional Tool Evidence:\n{evidence_block}"
    prompt = (
        f"{prompt}\n\n"
        "Output guardrails:\n"
        "- Return only your final answer line starting with ANSWER: <final answer>\n"
        "- Do not output tool-call markup, XML tags, or thinking traces."
    )
    system_msg = strategy.build_system_prompt(ctx)
    llm_params = strategy.get_llm_params(ctx)
    max_tokens = int(llm_params.get("max_tokens", 8192))
    temperature = float(llm_params.get("temperature", 0.0))

    start_ms = time.time() * 1000
    ttft_ms = 0
    raw_content_parts: list[str] = []
    reply_parts: list[str] = []
    reasoning_parts: list[str] = []

    stream_enabled = os.getenv("LLM_STREAM", "1").lower() not in {"0", "false", "no"}
    usage = None
    finish_reason = ""

    def _run_llm_call(use_stream: bool):
        nonlocal ttft_ms, finish_reason, usage
        if use_stream:
            stream = llm_client.chat.completions.create(
                model=model_name,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=temperature,
                stream=True,
            )
            for chunk in stream:
                if chunk.choices and getattr(chunk.choices[0], "finish_reason", None):
                    finish_reason = str(chunk.choices[0].finish_reason)
                if chunk.choices and chunk.choices[0].delta:
                    delta = chunk.choices[0].delta
                    content = delta.content or ""
                    reasoning = (
                        getattr(delta, "reasoning_content", None)
                        or getattr(delta, "reasoning", None)
                        or ""
                    )
                    text = reasoning or content
                    if ticker is not None:
                        ticker.feed(reasoning=reasoning, answer=content)
                    if reasoning:
                        reasoning_parts.append(reasoning)
                    if content:
                        reply_parts.append(content)
                    if text:
                        if not ttft_ms:
                            ttft_ms = int(time.time() * 1000 - start_ms)
                        raw_content_parts.append(text)
                if hasattr(chunk, "usage") and chunk.usage:
                    usage = chunk.usage
            return

        response = llm_client.chat.completions.create(
            model=model_name,
            messages=[
                {"role": "system", "content": system_msg},
                {"role": "user", "content": prompt},
            ],
            max_tokens=max_tokens,
            temperature=temperature,
        )
        content = response.choices[0].message.content or ""
        if content:
            reply_parts.append(content)
            raw_content_parts.append(content)
        finish_reason = str(getattr(response.choices[0], "finish_reason", "") or "")
        usage = response.usage
        ttft_ms = ttft_ms or getattr(response, "ttft_ms", 0) or int((time.time() * 1000 - start_ms) * 0.1)

    if stream_enabled and http_client and agent_id:
        try:
            await asyncio.to_thread(_run_llm_call, True)
        except Exception as e:
            raw_content_parts.clear()
            reply_parts.clear()
            reasoning_parts.clear()
            if "stream" in str(e).lower():
                await asyncio.to_thread(_run_llm_call, False)
            else:
                raise
    else:
        await asyncio.to_thread(_run_llm_call, False)

    if not raw_content_parts and stream_enabled and http_client and agent_id:
        await asyncio.to_thread(_run_llm_call, False)

    reply = "".join(reply_parts)
    raw_content = reply if reply.strip() else "".join(reasoning_parts)

    total_time_ms = int(time.time() * 1000 - start_ms)
    answer = extract_answer(raw_content)
    if not answer and reasoning_parts and reply.strip():
        answer = extract_answer("".join(reasoning_parts))
    answer = _sanitize_strategy_answer(strategy, answer, ctx.rules)
    if _is_invalid_answer_candidate(answer):
        answer = ""

    if not answer and evidence_lines:
        answer = await asyncio.to_thread(
            _derive_answer_from_evidence,
            llm_client=llm_client,
            model_name=model_name,
            challenge_description=str(ctx.description or ""),
            challenge_rules=str(ctx.rules or ""),
            evidence_lines=list(evidence_lines or []),
            max_tokens=max_tokens,
        )
        answer = _sanitize_strategy_answer(strategy, answer, ctx.rules)
        if _is_invalid_answer_candidate(answer):
            answer = ""

    if not answer and finish_reason != "length":
        strict_system_msg = (
            "Return only one line in exact format: ANSWER: <final answer>. "
            "No preamble, no tags, no explanation, no additional lines."
        )
        try:
            strict_response = await asyncio.to_thread(
                llm_client.chat.completions.create,
                model=model_name,
                messages=[
                    {"role": "system", "content": strict_system_msg},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=max_tokens,
                temperature=0.0,
                stream=False,
            )
            raw_content = strict_response.choices[0].message.content or ""
            usage = strict_response.usage
            total_time_ms = int(time.time() * 1000 - start_ms)
            answer = extract_answer(raw_content)
            if not answer and raw_content.strip():
                first_line = raw_content.strip().splitlines()[0]
                answer = _sanitize_strategy_answer(strategy, first_line, ctx.rules)
            else:
                answer = _sanitize_strategy_answer(strategy, answer, ctx.rules)
        except Exception:
            pass

    if _is_invalid_answer_candidate(answer):
        answer = ""

    if broadcast_thought and http_client and agent_id:
        try:
            await asyncio.to_thread(
                http_client.broadcast_thought,
                agent_id,
                f"💭 Solved with {model_name} in {total_time_ms / 1000:.1f}s.",
            )
        except Exception:
            pass

    usage_dict = {
        "finish_reason": finish_reason,
        "prompt_tokens": getattr(usage, "prompt_tokens", 0) if usage else 0,
        "completion_tokens": getattr(usage, "completion_tokens", 0) if usage else 0,
        "total_tokens": getattr(usage, "total_tokens", 0) if usage else 0,
    }
    streamed_text = "".join(raw_content_parts) or raw_content
    if not usage_dict["total_tokens"] and streamed_text:
        usage_dict["total_tokens"] = len(streamed_text.split()) * 2
    ttft_ms = ttft_ms or int(total_time_ms * 0.1)

    return answer, raw_content, model_name, usage_dict, ttft_ms, total_time_ms


def _submit_with_retry(
    http_client: HttpArenaClient,
    *,
    agent_id: str,
    answer: str,
    client_metrics: dict[str, Any],
    challenge_type: str | None = None,
):
    """Submit final answer with bounded exact-same-answer retry on transient network errors."""
    last_exc: Exception | None = None
    for attempt in range(1, 4):
        try:
            return http_client.submit(
                agent_id=agent_id,
                answer=answer,
                client_metrics=client_metrics,
                challenge_type=challenge_type,
            )
        except ArenaConnectionError as exc:
            last_exc = exc
            if attempt < 3:
                time.sleep(float(attempt))
                continue
            raise
        except ArenaAPIError:
            raise
    if last_exc:
        raise last_exc
    raise RuntimeError("Submit failed unexpectedly")


async def main():
    """Main agent loop."""
    strategy = MyStrategy()
    agent_id = (
        os.getenv("AGENT_ID")
        or str(getattr(strategy, "agent_id", "")).strip()
        or "simple-agent"
    ).strip()
    agent_name = (
        os.getenv("AGENT_NAME")
        or str(getattr(strategy, "agent_name", "")).strip()
        or "Sothiss Agent"
    ).strip()
    os.environ["AGENT_ID"] = agent_id
    # Practice is shared: a default id lets another team's run replace yours.
    id_problem = agent_id_problem(os.environ["AGENT_ID"])
    if id_problem:
        raise SystemExit(f"❌ {id_problem}")
    os.environ["AGENT_NAME"] = agent_name
    print(f"🤖 {agent_name} starting...")
    print(f"   Agent ID: {agent_id}")

    ensure_connected()

    # Initialize clients
    api_base = get_api_base()
    mcp_url = get_mcp_url()
    llm_host = get_proxy_host()
    api_key = get_arena_api_key()
    llm_api_key = api_key

    print(f"   API: {api_base}")
    print(f"   MCP: {mcp_url}")
    print(f"   LLM: {llm_host}")
    print()

    # HTTP client for Agent Gauntlet coordination
    http_client = HttpArenaClient(api_base=api_base, api_key=api_key)

    if not HAS_OPENAI:
        raise RuntimeError("Missing dependency: openai. Install with `pip install openai`.")
    
    # Step 1: Register with Agent Gauntlet
    print("📝 Registering with Agent Gauntlet...")
    session = http_client.register(agent_id, agent_name)
    print(f"   Session: {session.session_id}")
    print(f"   Status: {session.status}")
    session_monitor = monitor_session(http_client, agent_id).start()
    
    # Step 2: Get challenge from MCP
    print("\n🎯 Getting challenge...")
    async with McpArenaClient(mcp_url) as mcp_client:
        tool_defs = await mcp_client.list_tool_defs()
        tools = [str(getattr(t, "name", "") or "").strip() for t in tool_defs if str(getattr(t, "name", "") or "").strip()]
        if not tools:
            tools = await mcp_client.list_tools()
        modality = McpArenaClient.detect_modality(tools, agent_id=agent_id)
        usage_scope = http_client.fetch_usage_scope() or resolve_usage_scope()
        if usage_scope:
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope

        live_prompt_tokens = 0
        live_completion_tokens = 0
        live_total_tokens = 0
        active_model_name = ""
        metrics_started_ms = 0.0
        reporter_stop = asyncio.Event()
        metrics_task: asyncio.Task | None = None

        def _elapsed_metrics_ms() -> int:
            if metrics_started_ms <= 0:
                return 0
            return int(max(0.0, time.time() * 1000 - metrics_started_ms))

        async def _refresh_live_usage() -> None:
            nonlocal live_prompt_tokens, live_completion_tokens, live_total_tokens
            try:
                usage = await asyncio.to_thread(
                    _fetch_proxy_usage,
                    llm_host,
                    llm_api_key,
                    agent_id,
                    usage_scope,
                )
            except Exception:
                usage = None
            if not isinstance(usage, dict):
                return
            live_prompt_tokens = _coerce_nonnegative_int(usage.get("prompt_tokens"))
            live_completion_tokens = _coerce_nonnegative_int(usage.get("completion_tokens"))
            live_total_tokens = _coerce_nonnegative_int(usage.get("total_tokens"))

        async def _push_live_status(status: str = "running") -> None:
            await _refresh_live_usage()
            try:
                await asyncio.to_thread(
                    http_client.update_status,
                    agent_id,
                    status,
                    _build_live_metrics(
                        active_model_name,
                        {
                            "prompt_tokens": live_prompt_tokens,
                            "completion_tokens": live_completion_tokens,
                            "total_tokens": live_total_tokens,
                        },
                        _elapsed_metrics_ms(),
                    ),
                )
            except Exception:
                return

        async def _runtime_metrics_reporter() -> None:
            while not reporter_stop.is_set():
                await _push_live_status("running")
                try:
                    await asyncio.wait_for(reporter_stop.wait(), timeout=2.0)
                except asyncio.TimeoutError:
                    continue

        async def _start_metrics_reporter(model_name: str) -> None:
            nonlocal active_model_name, metrics_started_ms, metrics_task
            active_model_name = str(model_name or "").strip()
            metrics_started_ms = time.time() * 1000
            reporter_stop.clear()
            await _push_live_status("running")
            metrics_task = asyncio.create_task(_runtime_metrics_reporter())

        async def _stop_metrics_reporter() -> None:
            reporter_stop.set()
            if metrics_task is not None:
                try:
                    await asyncio.wait_for(metrics_task, timeout=2.0)
                except Exception:
                    if not metrics_task.done():
                        metrics_task.cancel()
            await _push_live_status("running")

        if modality == "image":
            challenge = None
            while True:
                try:
                    challenge = await mcp_client.get_image_challenge(agent_id)
                    break
                except McpArenaError as e:
                    message = str(e).lower()
                    if "locked" in message or "waiting for organizer" in message:
                        print("   Lobby open; waiting for organizer to start battle...")
                        await asyncio.sleep(2.0)
                    else:
                        raise
            print_challenge(challenge)
            usage_scope = await asyncio.to_thread(http_client.fetch_usage_scope) or resolve_usage_scope()
            if usage_scope:
                os.environ["ARENA_USAGE_SCOPE"] = usage_scope

            available_models = await asyncio.to_thread(fetch_available_models, llm_host, llm_api_key)
            image_rules = "\n".join(
                part
                for part in (challenge.prompt, challenge.reference_notes)
                if isinstance(part, str) and part.strip()
            )
            image_prompt = (challenge.prompt or challenge.description or "").strip()
            image_ctx = _build_context(
                challenge_type=challenge.challenge_type,
                difficulty=challenge.difficulty,
                description=challenge.description,
                rules=image_rules,
                max_time_s=challenge.max_time_s,
                available_models=available_models,
                image_url=challenge.input_image_uri or None,
            )
            ranked_models = strategy.rank_models(image_ctx, available_models)
            model_name = strategy.pick_model("solve", ranked_models, image_ctx)
            model_name = require_explicit_model(
                model_name,
                available_models,
                source="python_simple agent",
            )
            print(f"   Selected model: {model_name}")

            async def _broadcast_img_thought(msg: str) -> None:
                try:
                    await mcp_client.broadcast_image_thought(msg, agent_id)
                except Exception:
                    try:
                        await asyncio.to_thread(http_client.broadcast_thought, agent_id, msg)
                    except Exception:
                        pass

            await _broadcast_img_thought(f"Selected image model: {model_name}")
            await _start_metrics_reporter(model_name)

            start_ms = time.time() * 1000
            prompt_text = strategy.build_image_prompt(image_ctx).strip() or image_prompt
            image_tools = [
                tool_name
                for tool_name in ("image_edit", "image_generate", "image_analyze")
                if tool_name in tools
            ]
            image_tool_sequence = _plan_image_tool_sequence(
                strategy,
                image_ctx,
                image_tools,
            )
            selected_tool = image_tool_sequence[-1] if image_tool_sequence else ""
            tool_result: dict = {}
            mcp_session_dead = False

            async def _call_image_tool_for_model(name: str, base_args: dict, current_model: str) -> dict:
                nonlocal mcp_session_dead
                proxy_args = build_image_tool_arguments(
                    tool_defs,
                    name,
                    selected_model=current_model,
                    llm_api_key=llm_api_key,
                    arena_api_key=api_key,
                )
                full_args = {**base_args, **proxy_args}
                try:
                    result = await mcp_client.call_tool(name, full_args)
                    return result if isinstance(result, dict) else {}
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    mcp_session_dead = True
                    print(f"   Image tool {name} failed ({type(exc).__name__}): {exc}")
                    return {"error": str(exc)}

            if (
                len(image_tool_sequence) > 1
                and image_tool_sequence[0] == "image_analyze"
                and challenge.input_image_uri
            ):
                print("   Using image_analyze before output tool")
                analysis_result = await _call_image_tool_for_model(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                    },
                    model_name,
                )
                analysis_text = str(analysis_result.get("text") or "").strip()
                if analysis_text:
                    await _broadcast_img_thought(f"Image analysis: {analysis_text[:180]}")
                    prompt_text = (
                        f"{prompt_text}\n\n"
                        "Source-image analysis to preserve while transforming: "
                        f"{analysis_text[:1000]}"
                    )

            # Determine primary image output tool and base arguments
            target_tool = ""
            base_tool_args: dict[str, Any] = {}
            if (
                selected_tool == "image_edit"
                and challenge.input_image_uri
                and "image_edit" in image_tools
            ):
                target_tool = "image_edit"
                base_tool_args = {
                    "image_uri": challenge.input_image_uri,
                    "prompt": prompt_text,
                    "agent_id": agent_id,
                }
            elif selected_tool == "image_generate" and "image_generate" in image_tools:
                target_tool = "image_generate"
                base_tool_args = {
                    "prompt": prompt_text,
                    "agent_id": agent_id,
                }
            elif challenge.input_image_uri and "image_edit" in image_tools:
                target_tool = "image_edit"
                selected_tool = "image_edit"
                base_tool_args = {
                    "image_uri": challenge.input_image_uri,
                    "prompt": prompt_text,
                    "agent_id": agent_id,
                }
            elif "image_generate" in image_tools:
                target_tool = "image_generate"
                selected_tool = "image_generate"
                base_tool_args = {
                    "prompt": prompt_text,
                    "agent_id": agent_id,
                }

            if target_tool:
                # Try up to 3 ranked image models if the first fails or returns no image_uri
                candidate_models = [model_name] + [m for m in ranked_models if m != model_name]
                for attempt_idx, candidate_model in enumerate(candidate_models[:3], start=1):
                    if mcp_session_dead:
                        break
                    print(f"   Using {target_tool} tool with {candidate_model} (attempt {attempt_idx})")
                    tool_result = await _call_image_tool_for_model(
                        target_tool,
                        base_tool_args,
                        candidate_model,
                    )
                    maybe_uri = str(tool_result.get("image_uri") or "").strip()
                    if maybe_uri:
                        model_name = candidate_model
                        break
                    err_msg = tool_result.get("error") or "empty image_uri"
                    print(f"   Tool warning ({candidate_model}): {err_msg}")
            elif (
                selected_tool == "image_analyze"
                and challenge.input_image_uri
                and "image_analyze" in image_tools
            ):
                print("   Using image_analyze tool (no image output tool available)")
                tool_result = await _call_image_tool_for_model(
                    "image_analyze",
                    {
                        "image_uri": challenge.input_image_uri,
                        "question": prompt_text,
                        "agent_id": agent_id,
                    },
                    model_name,
                )
                analysis_text = str(tool_result.get("text") or "").strip()
                if analysis_text:
                    await _broadcast_img_thought(f"Image analysis: {analysis_text[:180]}")

            output_image_uri = str(tool_result.get("image_uri") or "").strip()
            if not output_image_uri and challenge.input_image_uri:
                output_image_uri = challenge.input_image_uri
            if not output_image_uri:
                if mcp_session_dead:
                    await session_monitor.stop()
                    raise RuntimeError(
                        "Image MCP tool failed and no input_image_uri is available "
                        "to submit; refusing to invent image bytes"
                    )
                output_image_uri = BLANK_PNG_DATA_URI

            total_time_ms = int(time.time() * 1000 - start_ms)
            await _stop_metrics_reporter()
            client_metrics = {
                "model_name": model_name,
                "planner_tool": selected_tool,
                "total_tokens": str(live_total_tokens),
                "prompt_tokens": str(live_prompt_tokens),
                "completion_tokens": str(live_completion_tokens),
                "ttft_ms": 0,
                "total_time_ms": total_time_ms,
            }
            rationale_fn = getattr(strategy, "build_image_rationale", None)
            if callable(rationale_fn):
                image_rationale = str(
                    rationale_fn(
                        image_ctx,
                        selected_tool=selected_tool,
                        model_name=model_name,
                        prompt=str(challenge.prompt or challenge.description or ""),
                        reference_notes=str(challenge.reference_notes or ""),
                    )
                ).strip()
            else:
                image_rationale = f"simple_agent dynamic image flow ({selected_tool})"

            if mcp_session_dead:
                await session_monitor.stop()
                print("   MCP session unavailable; submitting image over REST")
                image_submit_result = _submit_with_retry(
                    http_client,
                    agent_id=agent_id,
                    answer=output_image_uri,
                    client_metrics=client_metrics,
                    challenge_type="image",
                )
            else:
                image_submit_result = await mcp_client.submit_image(
                    agent_id=agent_id,
                    image_uri=output_image_uri,
                    client_metrics=client_metrics,
                    rationale=image_rationale,
                )
            for line in submission_summary_lines(image_submit_result):
                print(f"   {line}")
            await session_monitor.stop()
            print(f"   Image: {save_submitted_image(agent_id, output_image_uri, REPO_ROOT)}")
            if isinstance(image_submit_result, dict):
                image_result = image_submit_result
            else:
                image_result = {
                    "accepted": getattr(image_submit_result, "accepted", None),
                    "score": getattr(image_submit_result, "score", None),
                }
            score = image_result.get("score") if isinstance(image_result.get("score"), dict) else {}
            run_record = {
                "agent_id": agent_id,
                "challenge": challenge_record(challenge),
                "model": model_name,
                "image_tool_sequence": image_tool_sequence,
                "result": {
                    "accepted": image_result.get("accepted"),
                    "score": {key: value for key, value in score.items() if key != "output_image_uri"},
                },
            }
            print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
            print("\n✅ Agent completed!")
            return

        # Wait for organizer to start (challenge is locked while lobby is open)
        challenge = None
        while True:
            try:
                challenge = await mcp_client.get_challenge(agent_id)
                break
            except McpArenaError as e:
                message = str(e).lower()
                if "locked" in message or "waiting for organizer" in message:
                    print("   Lobby open; waiting for organizer to start battle...")
                    await asyncio.sleep(2.0)
                else:
                    raise
        print_challenge(challenge)

        # Fetch usage scope, available models, and clue IDs concurrently to minimize latency
        scope_task = asyncio.to_thread(http_client.fetch_usage_scope)
        models_task = asyncio.to_thread(fetch_available_models, llm_host, llm_api_key)
        clue_ids_task = mcp_client.list_clues(agent_id)
        thought_task = asyncio.to_thread(
            http_client.broadcast_thought,
            agent_id,
            "Reading challenge, clues, and inspecting MCP environment...",
        )

        fetched_scope, available_models, clue_ids, _ = await asyncio.gather(
            scope_task,
            models_task,
            clue_ids_task,
            thought_task,
            return_exceptions=True,
        )

        if isinstance(fetched_scope, str) and fetched_scope.strip():
            usage_scope = fetched_scope.strip()
            os.environ["ARENA_USAGE_SCOPE"] = usage_scope
        if not isinstance(available_models, list):
            available_models = fetch_available_models(llm_host, llm_api_key)
        if not isinstance(clue_ids, list):
            clue_ids = []

        llm_client = OpenAI(
            base_url=llm_host,
            api_key=llm_api_key,
            default_headers=build_proxy_headers(agent_id, usage_scope),
        )
        print("   LLM: Enabled")
        print()

        raw_data = getattr(challenge, "raw_data", None)
        raw_data = raw_data if isinstance(raw_data, dict) else {}
        explicit_required_tools = list(raw_data.get("required_tools") or [])
        difficulty = str(raw_data.get("difficulty") or getattr(challenge, "difficulty", "unknown") or "unknown")

        model_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            difficulty=difficulty,
            description=challenge.description,
            rules=challenge.rules,
            max_time_s=challenge.max_time_s,
            available_models=available_models,
            required_tools=explicit_required_tools,
        )
        ranked_models = strategy.rank_models(model_ctx, available_models)
        model_name = strategy.pick_model("solve", ranked_models, model_ctx)
        model_name = require_explicit_model(
            model_name,
            available_models,
            source="python_simple agent",
        )
        print(f"   Selected model: {model_name}")
        await _start_metrics_reporter(model_name)

        # Fetch all clues concurrently
        print("\n📖 Reading clues...")
        clues: list[str] = []
        if clue_ids:
            clue_results = await asyncio.gather(
                *(mcp_client.get_clue(cid, agent_id) for cid in clue_ids),
                return_exceptions=True,
            )
            for item in clue_results:
                if hasattr(item, "text") and isinstance(item.text, str) and item.text.strip():
                    clues.append(item.text.strip())
        if not clues:
            clues = [str(clue_text) for clue_text in challenge.clues if str(clue_text).strip()]

        # Concurrently execute required/domain MCP tools and inspect MCP resources
        tools_exec_task = _enforce_required_tool_calls(
            mcp_client=mcp_client,
            agent_id=agent_id,
            challenge_type=str(challenge.challenge_type or ""),
            description=str(challenge.description or ""),
            rules=str(challenge.rules or ""),
            clues=clues,
            available_tool_names=[str(name) for name in tools],
            tool_defs=tool_defs,
            explicit_required_tools=explicit_required_tools,
            http_client=http_client,
            extra_context=str(getattr(challenge, "extra_text", "") or ""),
        )
        resources_task = _introspect_mcp_resources_and_prompts(mcp_client)
        tool_evidence_lines, resource_lines = await asyncio.gather(tools_exec_task, resources_task)
        all_evidence_lines = list(tool_evidence_lines or []) + list(resource_lines or [])

        # Step 3: Solve
        print("\n🧠 Solving...")
        solve_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            difficulty=difficulty,
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            required_tools=explicit_required_tools,
        )

        ticker = ReasoningTicker(model_name)
        answer, raw_response, model_name, usage, ttft_ms, total_time_ms = await solve_challenge(
            challenge,
            clues,
            llm_client,
            model_name,
            strategy,
            solve_ctx,
            http_client=http_client,
            agent_id=agent_id,
            broadcast_thought=True,
            evidence_lines=all_evidence_lines,
            ticker=ticker,
        )
        ticker.finish()

        async def _remaining_s() -> float:
            info = await mcp_client.time_remaining(agent_id)
            return float(info.get("time_remaining_s", 0.0))

        def _solve_with(retry_model: str):
            nonlocal ticker
            ticker = ReasoningTicker(retry_model)
            return solve_challenge(
                challenge,
                clues,
                llm_client,
                retry_model,
                strategy,
                solve_ctx,
                http_client=http_client,
                agent_id=agent_id,
                broadcast_thought=True,
                evidence_lines=all_evidence_lines,
                ticker=ticker,
            )

        answer, raw_response, model_name, usage, ttft_ms, total_time_ms = await _retry_after_length_stop(
            (answer, raw_response, model_name, usage, ttft_ms, total_time_ms),
            ranked_models=ranked_models,
            remaining_s=_remaining_s,
            solve_with=_solve_with,
        )
        ticker.finish()
        for line in summary_lines(
            model=model_name,
            elapsed_s=total_time_ms / 1000,
            usage=usage,
            finish_reason=str(usage.get("finish_reason") or ""),
            answer=answer,
            ticker=ticker,
        ):
            print(line)

        answer = strategy.sanitize_answer(answer, str(challenge.rules or ""))
        if _is_invalid_answer_candidate(answer):
            answer = ""
        if not answer:
            print("   ⚠️  No valid ANSWER format found; using last line as fallback.")
            lines = [ln.strip() for ln in raw_response.strip().splitlines() if ln.strip()]
            last_line = strategy.sanitize_answer(lines[-1], str(challenge.rules or "")) if lines else ""
            answer = (
                last_line
                if last_line and len(last_line) < 400 and not _is_invalid_answer_candidate(last_line)
                else "unknown"
            )

        # Save draft and check time remaining concurrently
        draft_task = asyncio.to_thread(http_client.save_draft, agent_id, answer, "LLM solution")
        time_task = mcp_client.time_remaining(agent_id)
        _, time_info = await asyncio.gather(draft_task, time_task, return_exceptions=True)
        if not isinstance(time_info, dict):
            time_info = {"time_remaining_s": 0.0}

        remaining_s = float(time_info.get("time_remaining_s", 0.0))
        submit_ctx = _build_context(
            challenge_type=challenge.challenge_type,
            difficulty=difficulty,
            description=challenge.description,
            rules=challenge.rules,
            clues=clues,
            max_time_s=challenge.max_time_s,
            available_models=ranked_models,
            time_remaining_s=remaining_s,
            tokens_used=usage.get("total_tokens", 0),
            required_tools=explicit_required_tools,
        )
        revised_answer = strategy.on_time_warning(remaining_s, answer, submit_ctx)
        if isinstance(revised_answer, str) and revised_answer.strip():
            answer = revised_answer.strip()
        print(f"   Time remaining: {remaining_s:.1f}s")

    # Step 4: Submit the extracted answer with real metrics
    print("\n📤 Submitting answer...")
    await _stop_metrics_reporter()

    result = await asyncio.to_thread(
        _submit_with_retry,
        http_client,
        agent_id=agent_id,
        answer=answer,
        client_metrics={
            "model_name": model_name,
            "total_tokens": str(live_total_tokens or usage.get("total_tokens", 0)),
            "prompt_tokens": str(live_prompt_tokens or usage.get("prompt_tokens", 0)),
            "completion_tokens": str(live_completion_tokens or usage.get("completion_tokens", 0)),
            "ttft_ms": ttft_ms,
            "total_time_ms": total_time_ms,
        },
    )

    print(f"   Accepted: {result.accepted}")
    print(f"   Status: {result.status}")
    if result.score:
        print(f"   Score: {result.score.get('final_score', 0)}")
        print(f"   Quality: {result.score.get('quality_score', 0)}")
        print(f"   Speed: {result.score.get('speed_score', 0)}")
    if missing_tools_note(result):
        print(f"   ⚠️  {missing_tools_note(result)}")

    await session_monitor.stop()
    run_record = {
        "agent_id": agent_id,
        "challenge": challenge_record(challenge),
        "model": model_name,
        "answer": answer,
        "usage": usage,
        "total_time_ms": total_time_ms,
        "result": {
            "accepted": result.accepted,
            "status": result.status,
            "score": result.score,
        },
    }
    print(f"   Run record: {save_run_record(agent_id, run_record, REPO_ROOT)}")
    print("\n✅ Agent completed!")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except asyncio.CancelledError:
        raise SystemExit(0)
    except ModelSelectionError as exc:
        print(f"   {exc}")
        raise SystemExit(1)
